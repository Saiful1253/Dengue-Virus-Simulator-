#include <GL/glut.h>
#include <cmath>

float mosquitoX = -0.8f;  // mosquito initial x position
bool spray = false;
bool mosquitoAlive = true;

// Draw mosquito (simplified circle with wings)
void drawMosquito(float x, float y) {
    if (!mosquitoAlive) return;

    // Body
    glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
    for (int i = 0; i < 360; i++) {
        float angle = i * 3.14 / 180;
        glVertex2f(x + 0.02 * cos(angle), y + 0.02 * sin(angle));
    }
    glEnd();

    // Wings
    glColor3f(0.5f, 0.5f, 0.5f);
    glBegin(GL_TRIANGLES);
    glVertex2f(x, y + 0.02);
    glVertex2f(x + 0.03, y + 0.05);
    glVertex2f(x + 0.01, y + 0.02);
    glEnd();

    glBegin(GL_TRIANGLES);
    glVertex2f(x, y + 0.02);
    glVertex2f(x - 0.03, y + 0.05);
    glVertex2f(x - 0.01, y + 0.02);
    glEnd();
}

// Draw spray line
void drawSpray() {
    if (!spray) return;
    glColor3f(0.0f, 1.0f, 1.0f);
    glBegin(GL_LINES);
    glVertex2f(0.6f, -0.8f);
    glVertex2f(mosquitoX, 0.0f);
    glEnd();
}

// Display callback
void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    drawMosquito(mosquitoX, 0.0f);
    drawSpray();

    glutSwapBuffers();
}

// Timer function for animation
void update(int value) {
    if (mosquitoAlive) {
        mosquitoX += 0.01f;
        if (mosquitoX > 1.0f) mosquitoX = -1.0f;

        // Check if spray hit
        if (spray && fabs(mosquitoX - 0.6f) < 0.1f) {
            mosquitoAlive = false;
        }
    }

    spray = false;
    glutPostRedisplay();
    glutTimerFunc(100, update, 0);
}

// Keyboard input
void keyboard(unsigned char key, int x, int y) {
    if (key == 's' || key == 'S') {
        spray = true;
    }
    if (key == 'r' || key == 'R') {
        mosquitoX = -0.8f;
        mosquitoAlive = true;
    }
}

// Initialize OpenGL
void init() {
    glClearColor(1.0f, 1.0f, 0.9f, 1.0f); // Light background
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(-1, 1, -1, 1);
}

// Main
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("Dengue Prevention Simulator");

    init();
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutTimerFunc(100, update, 0);
    glutMainLoop();
    return 0;
}
